import {StyleSheet, Text, View} from 'react-native';
import React from 'react';

const RewindingSearchOrders = () => {
  return (
    <View>
      <Text>RewindingSearchOrders</Text>
    </View>
  );
};

export default RewindingSearchOrders;

const styles = StyleSheet.create({});
