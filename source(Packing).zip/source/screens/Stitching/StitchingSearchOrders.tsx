import {StyleSheet, Text, View} from 'react-native';
import React from 'react';

const StitchingSearchOrders = () => {
  return (
    <View>
      <Text>StitchingSearchOrders</Text>
    </View>
  );
};

export default StitchingSearchOrders;

const styles = StyleSheet.create({});
