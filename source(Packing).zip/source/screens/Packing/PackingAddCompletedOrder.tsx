// import {RouteProp, useNavigation, useRoute} from '@react-navigation/native';
// import moment from 'moment';
// import React, {memo, useCallback, useRef, useState} from 'react';
// import {Pressable, ScrollView, StyleSheet, View} from 'react-native';
// import {packing_set_order_complete} from '../../api/apis';
// import {packing_set_order_complete_body} from '../../api/BodyTypes';
// import {packing_complete_orders_response} from '../../api/ResponseTypes';
// import {images} from '../../assets/images';
// import {Font500, Font700} from '../../components/fonts/Fonts';
// import Button from '../../components/styles/Button';
// import CommonHeader from '../../components/styles/CommonHeader';
// import Input, {InputRef} from '../../components/styles/Input';
// import {colors} from '../../constants/colors';
// import {fontFamily} from '../../constants/fontFamily';
// import {AppNavigationProp, AppStackParamList} from '../../stacks/StackTypes';
// import {checkInput} from '../../utils/CheckInput';
// import {error, ShowToast} from '../../utils/ErrorHandler';

// type PackingAddCompletedOrderRouteProp = RouteProp<
//   AppStackParamList,
//   'PackingAddCompletedOrder'
// >;

// enum Step {
//   YES = 'Yes',
//   NO = 'No',
// }

// const PackingAddCompletedOrder = () => {
//   const route = useRoute<PackingAddCompletedOrderRouteProp>();

//   const ItemData = route?.params?.data;

//   const {goBack} = useNavigation<AppNavigationProp>();

//   const [selectedStep, setSelectedStep] = useState<Step>(Step.YES);
//   const [loader, setLoader] = useState(false);

//   const labour = useRef<InputRef>(null);
//   const date = useRef<InputRef>(null);
//   const bags = useRef<InputRef>(null);
//   const steping_required = useRef<InputRef>(null);

//   const onCompleteOrderHandler = useCallback(async () => {
//     if (
//       checkInput(labour?.current?.get(), 'Labour Require for complete order')
//     ) {
//       return;
//     }

//     if (checkInput(bags?.current?.get(), 'Bags Require for complete order')) {
//       return;
//     }

//     if (
//       checkInput(
//         steping_required?.current?.get(),
//         'Steping Require for complete order',
//       )
//     ) {
//       return;
//     }

//     const body: packing_set_order_complete_body = {
//       packing_production_order_id: ItemData?.packing_production_order_id,
//       labour_name: labour?.current?.get(),
//       date: date?.current?.get(),
//       steping_required: steping_required?.current?.get(),
//       bags_per_box_qty: bags?.current?.get(),
//     };

//     try {
//       setLoader(true);
//       const response: {data: packing_complete_orders_response} =
//         await packing_set_order_complete(body);
//       ShowToast(response?.data?.message);
//       goBack();
//       setLoader(false);
//     } catch (err) {
//       setLoader(false);
//       error(err);
//     } finally {
//       setLoader(false);
//     }
//   }, [ItemData, goBack]);

//   return (
//     <View style={styles.root}>
//       <CommonHeader title="Packing Orders" />
//       <ScrollView
//         showsVerticalScrollIndicator={false}
//         contentContainerStyle={styles.scrollRoot}>
//         <View style={styles.container}>
//           <Font500 style={styles.orderId}>{ItemData.order_id}</Font500>
//           <View style={styles.detail}>
//             <View style={styles.detailContainer}>
//               <View style={styles.detailSubContainer}>
//                 <Font500 style={styles.label}>{'Product Name : '}</Font500>
//                 <Font700 style={styles.value}>{ItemData?.packing_name}</Font700>
//               </View>
//             </View>
//             <View style={styles.line} />
//             <View style={styles.detailContainer}>
//               <View style={styles.detailSubContainer}>
//                 <Font500 style={styles.label}>{'P. Type : '}</Font500>
//                 <Font700 style={styles.value}>{'14X280'}</Font700>
//               </View>
//               <View style={styles.detailSubContainer}>
//                 <Font500 style={styles.label}>{'Colors : '}</Font500>
//                 <Font700 style={styles.value}>{ItemData?.color}</Font700>
//               </View>
//             </View>
//             <View style={styles.line} />
//             <View style={styles.detailContainer}>
//               <View style={styles.detailSubContainer}>
//                 <Font500 style={styles.label}>{'P. Name : '}</Font500>
//                 <Font700 style={styles.value}>{'ABC'}</Font700>
//               </View>
//               <View style={styles.detailSubContainer}>
//                 <Font500 style={styles.label}>{'Width : '}</Font500>
//                 <Font700 style={styles.value}>{ItemData?.width}</Font700>
//               </View>
//             </View>
//             <View style={styles.line} />
//             <View style={styles.detailContainer}>
//               <View style={styles.detailSubContainer}>
//                 <Font500 style={styles.label}>{'Carton : '}</Font500>
//                 <Font700 style={styles.value}>{'5'}</Font700>
//               </View>
//               <View style={styles.detailSubContainer}>
//                 <Font500 style={styles.label}>{'Length : '}</Font500>
//                 <Font700 style={styles.value}>{ItemData?.length}</Font700>
//               </View>
//             </View>
//             <View style={styles.line} />
//             <View style={styles.detailContainer}>
//               <View style={styles.detailSubContainer}>
//                 <Font500 style={styles.label}>{'Sticker : '}</Font500>
//                 <Font700 style={styles.value}>{'YES'}</Font700>
//               </View>
//               <View style={styles.detailSubContainer}>
//                 <Font500 style={styles.label}>{'Rolls : '}</Font500>
//                 <Font700 style={styles.value}>{'100'}</Font700>
//               </View>
//             </View>
//             <View style={styles.line} />
//             <View style={styles.detailContainer}>
//               <View style={styles.detailSubContainer}>
//                 <Font500 style={styles.label}>{'Pipe : '}</Font500>
//                 <Font700 style={styles.value}>{'14x208'}</Font700>
//               </View>
//               <View style={styles.detailSubContainer}>
//                 <Font500 style={styles.label}>{'Bharati : '}</Font500>
//                 <Font700 style={styles.value}>{'30'}</Font700>
//               </View>
//             </View>
//             <Button
//               icon={images.print}
//               iconStyle={{height: 28, width: 28}}
//               buttonTextStyle={styles.printButtonText}
//               buttonContainerStyle={styles.printButton}>
//               {'Print'}
//             </Button>
//           </View>
//           <Input
//             ref={labour}
//             config={{placeholder: 'Labour Name'}}
//             rootStyle={styles.inputContainer}
//             label="Labour Name"
//           />
//           <Input
//             ref={date}
//             default_value={moment().format('DD-MM-YYYY')}
//             rootStyle={styles.inputContainer}
//             label="Date (DD-MM-YYYY)"
//             config={{editable: false}}
//           />
//           <Input
//             ref={bags}
//             config={{placeholder: '2'}}
//             rootStyle={styles.inputContainer}
//             label="Bags/Box Qty"
//           />

//           <View style={styles.stepContainer}>
//             <Font500 style={styles.stepLabel}>{'STEPING REQUIRED'}</Font500>
//             <View style={styles.stepSubContainer}>
//               <Pressable
//                 onPress={() => setSelectedStep(Step.YES)}
//                 style={[
//                   selectedStep === Step.YES ? styles.selectedStep : styles.step,
//                 ]}>
//                 <Font500
//                   style={[
//                     selectedStep === Step.YES
//                       ? styles?.selectedStepValue
//                       : styles?.stepValue,
//                   ]}>
//                   {Step.YES}
//                 </Font500>
//               </Pressable>
//               <Pressable
//                 onPress={() => setSelectedStep(Step.NO)}
//                 style={[
//                   selectedStep === Step.NO ? styles.selectedStep : styles.step,
//                 ]}>
//                 <Font500
//                   style={[
//                     selectedStep === Step.NO
//                       ? styles?.selectedStepValue
//                       : styles?.stepValue,
//                   ]}>
//                   {Step.NO}
//                 </Font500>
//               </Pressable>
//             </View>
//           </View>

//           <Input
//             ref={steping_required}
//             config={{placeholder: 'Steping Required'}}
//             rootStyle={styles.inputContainer}
//             label="Remarks"
//           />
//         </View>
//         <Button
//           loader={loader}
//           icon={images.complete}
//           iconStyle={styles.buttonIcon}
//           onPress={onCompleteOrderHandler}
//           buttonTextStyle={styles.buttonText}
//           buttonContainerStyle={styles.button}>
//           {'Save'}
//         </Button>
//       </ScrollView>
//     </View>
//   );
// };

// export default memo(PackingAddCompletedOrder);

// const styles = StyleSheet.create({
//   root: {
//     flex: 1,
//   },
//   scrollRoot: {
//     flexGrow: 1,
//     paddingBottom: 100,
//   },
//   container: {
//     padding: 17,
//     marginTop: 32,
//     borderWidth: 1,
//     borderRadius: 12,
//     marginHorizontal: 24,
//     borderColor: colors.color_D5E4E3,
//     backgroundColor: colors.color_F4F8F7,
//   },
//   orderId: {
//     fontSize: 18,
//   },
//   detail: {
//     backgroundColor: colors.white,
//     borderRadius: 12,
//     paddingVertical: 3,
//     marginTop: 23,
//   },
//   detailContainer: {
//     flexDirection: 'row',
//     paddingHorizontal: 13,
//     paddingVertical: 10,
//   },
//   detailSubContainer: {
//     flex: 1,
//     flexDirection: 'row',
//   },
//   label: {
//     fontSize: 14,
//     color: colors.color_777777,
//   },
//   value: {fontSize: 14, color: colors.color_0B2624},
//   line: {
//     height: 1,
//     backgroundColor: colors.color_E8DBDF,
//   },
//   printButton: {
//     marginTop: 26,
//     borderWidth: 1,
//     marginBottom: 19,
//     marginHorizontal: 16,
//     borderColor: colors.color_22534F,
//     backgroundColor: colors.color_F4F8F7,
//   },
//   printButtonText: {
//     color: colors.color_22534F,
//     paddingHorizontal: 6,
//     fontFamily: fontFamily.Font500,
//   },
//   inputContainer: {
//     marginTop: 16,
//   },
//   stepContainer: {
//     marginTop: 14,
//   },
//   stepLabel: {
//     fontSize: 14,
//     marginBlock: 13,
//   },
//   stepSubContainer: {
//     flexDirection: 'row',
//   },
//   selectedStep: {
//     height: 37,
//     width: 100,
//     marginRight: 20,
//     borderRadius: 6,
//     borderWidth: 1,
//     paddingRight: 20,
//     flexDirection: 'row',
//     alignItems: 'center',
//     justifyContent: 'center',
//     paddingHorizontal: 20,
//     borderColor: colors.color_22534F,
//     backgroundColor: colors.color_22534F,
//   },
//   step: {
//     height: 37,
//     width: 100,
//     marginRight: 20,
//     borderRadius: 6,
//     borderWidth: 1,
//     paddingRight: 20,
//     flexDirection: 'row',
//     alignItems: 'center',
//     justifyContent: 'center',
//     paddingHorizontal: 20,
//     borderColor: colors.color_0B2624,
//     backgroundColor: colors.white,
//   },
//   stepIcon: {
//     height: 20,
//     width: 20,
//   },
//   selectedStepValue: {
//     fontSize: 14,
//     color: colors.white,
//   },
//   stepValue: {
//     fontSize: 14,
//     color: colors.color_0B2624,
//   },
//   button: {
//     marginVertical: 46,
//     marginHorizontal: 24,
//   },
//   buttonIcon: {height: 28, width: 28},
//   buttonText: {
//     fontSize: 16,
//     paddingHorizontal: 6,
//     fontFamily: fontFamily.Font500,
//   },
// });

import {
  RouteProp,
  useIsFocused,
  useNavigation,
  useRoute
} from "@react-navigation/native";
import moment from "moment";
import React, { memo, useCallback, useEffect, useRef, useState } from "react";
import {
  Pressable,
  ScrollView,
  StyleSheet,
  View,
  FlatList,
  RefreshControl
} from "react-native";
import {
  packing_order_history,
  packing_set_order_complete
} from "../../api/apis";
import {
  packing_order_history_body,
  packing_set_order_complete_body
} from "../../api/BodyTypes";
import {
  packing_complete_orders_response,
  packing_order_history_listing_response
} from "../../api/ResponseTypes";
import { images } from "../../assets/images";
import { Font500, Font700 } from "../../components/fonts/Fonts";
import Button from "../../components/styles/Button";
import CommonHeader from "../../components/styles/CommonHeader";
import Input, { InputRef } from "../../components/styles/Input";
import { colors } from "../../constants/colors";
import { fontFamily } from "../../constants/fontFamily";
import { AppNavigationProp, AppStackParamList } from "../../stacks/StackTypes";
import { checkInput } from "../../utils/CheckInput";
import { error, ShowToast } from "../../utils/ErrorHandler";
import EmptyList from "../../components/styles/EmptyList";
import PackingOrderHistoryItems, {
  PackingOrderHistoryItemType
} from "./PackingOrderHistoryItems";
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp
} from "react-native-responsive-screen";
import PrintModal, { PrintModalRef } from "../../components/model/PrintModal";

type PackingAddCompletedOrderRouteProp = RouteProp<
  AppStackParamList,
  "PackingAddCompletedOrder"
>;

enum Step {
  YES = "Yes",
  NO = "No"
}

const PackingAddCompletedOrder = () => {
  const route = useRoute<PackingAddCompletedOrderRouteProp>();
 
  const ItemData = route?.params?.data;
 
  const { goBack } = useNavigation<AppNavigationProp>();
  const [selectedStep, setSelectedStep] = useState<Step>(Step.YES);
 
  const [loader, setLoader] = useState(false);

  const labour = useRef<InputRef>(null);
  const date = useRef<InputRef>(null);
  const bags = useRef<InputRef>(null);
  const steping_required = useRef<InputRef>(null);

  const onCompleteOrderHandler = useCallback(async () => {
    if (
      checkInput(labour?.current?.get(), "Labour Require for complete order")
    ) {
      return;
    }

    if (checkInput(bags?.current?.get(), "Bags Require for complete order")) {
      return;
    }

    if (
      checkInput(
        steping_required?.current?.get(),
        "Steping Require for complete order"
      )
    ) {
      return;
    }

    const body: packing_set_order_complete_body = {
      packing_production_order_id: ItemData?.packing_production_order_id,
      labour_name: labour?.current?.get(),
      date: date?.current?.get(),
      steping_required: steping_required?.current?.get(),
      bags_per_box_qty: bags?.current?.get()
    };

    try {
      setLoader(true);
      const response: { data: packing_complete_orders_response } =
        await packing_set_order_complete(body);
      ShowToast(response?.data?.message);
      goBack();
      setLoader(false);
    } catch (err) {
      setLoader(false);
      error(err);
    } finally {
      setLoader(false);
    }
  }, [ItemData, goBack]);

  const [list, setList] = useState<PackingOrderHistoryItemType[]>([]);

  const [refresh, setRefresh] = useState<boolean>(false);

  const focus = useIsFocused();

  const getList = useCallback(async () => {
    const body: packing_order_history_body = {
      packing_production_order_id: ItemData?.packing_production_order_id
    };

    try {
      setLoader(true);
      const response: { data: packing_order_history_listing_response } =
        await packing_order_history(body);
      setList(response?.data?.data);
      setLoader(false);
    } catch (err: any) {
      setLoader(false);
      error(err);
    } finally {
      setLoader(false);
    }
  }, [ItemData, setLoader]);

  useEffect(() => {
    if (focus) {
      getList();
    }
  }, [getList, focus]);

  const refreshList = useCallback(async () => {
    const body: packing_order_history_body = {
      packing_production_order_id: ItemData?.packing_production_order_id
    };

    try {
      setRefresh(true);
      const response: { data: packing_order_history_listing_response } =
        await packing_order_history(body);
      setList(response?.data?.data);
      setLoader(false);
    } catch (err: any) {
      setRefresh(false);
      error(err);
    } finally {
      setRefresh(false);
    }
  }, [ItemData, setRefresh]);

  const renderItemHandler = useCallback(
    ({ item }: { item: PackingOrderHistoryItemType }) => {
      return <PackingOrderHistoryItems data={item} />;
    },
    []
  );

  const printModel = useRef<PrintModalRef>(null);

  const onPrintModalOPen = useCallback(() => {
    printModel?.current?.open();
  }, []);

  const ItemSeparatorComponent = () => <View style={styles.itemSeparator} />;
  return (
    <View style={styles.root}>
      <CommonHeader title="Packing Orders" />
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scrollRoot}
      >
        <View style={styles.container}>
          <Font500 style={styles.orderId}>{ItemData.order_id}</Font500>
          <View style={styles.detail}>
            <View style={styles.detailContainer}>
              <View style={styles.detailSubContainer}>
                <Font500 style={styles.label}>{"Product Name : "}</Font500>
                <Font700 style={[styles.value, { width: wp("45%") }]}>
                  {ItemData?.packing_name}
                </Font700>
              </View>
            </View>
            <View style={styles.line} />
            <View style={styles.detailContainer}>
              <View style={styles.detailSubContainer}>
                <Font500 style={styles.label}>{"Date : "}</Font500>
                <Font700 style={styles.value}>
                  {moment(ItemData?.date).format("DD/MM/YYYY")}
                </Font700>
              </View>
              <View style={styles.detailSubContainer}>
                <Font500 style={styles.label}>{"Bundles : "}</Font500>
                <Font700 style={styles.value}>
                  {ItemData?.pending_bundle_qty}
                </Font700>
              </View>
            </View>
            <View style={styles.line} />
            <View style={styles.detailContainer}>
              <View style={styles.detailSubContainer}>
                <Font500 style={styles.label}>{"P. Type : "}</Font500>
                <Font700 style={styles.value}>
                  {ItemData?.sticching_packing_type}
                </Font700>
              </View>
              <View style={styles.detailSubContainer}>
                <Font500 style={styles.label}>{"Colors : "}</Font500>
                <Font700 style={styles.value}>{ItemData?.color}</Font700>
              </View>
            </View>
            <View style={styles.line} />
            <View style={styles.detailContainer}>
              {/* <View style={styles.detailSubContainer}>
                <Font500 style={styles.label}>{"P. Name : "}</Font500>
                <Font700 style={styles.value}>{ItemData?.packing_name}</Font700>
              </View> */}
               
              <View style={styles.detailSubContainer}>
                <Font500 style={styles.label}>{"Width : "}</Font500>
                <Font700 style={styles.value}>{ItemData?.width}</Font700>
              </View>
              <View style={styles.detailSubContainer}>
                <Font500 style={styles.label}>{"Length : "}</Font500>
                <Font700 style={styles.value}>{ItemData?.length}</Font700>
              </View>
            </View>
            <View style={styles.line} />
            <View style={styles.detailContainer}>
              <View style={styles.detailSubContainer}>
                <Font500 style={styles.label}>{"Gauge : "}</Font500>
                <Font700 style={styles.value}>{ItemData?.gage}</Font700>
              </View>
              <View style={styles.detailSubContainer}>
                <Font500 style={styles.label}>{"Bharati : "}</Font500>
                <Font700 style={styles.value}>
                  {ItemData?.packing_bharti}
                </Font700>
              </View>
            </View>
            <View style={styles.line} />
            <View style={styles.detailContainer}>
            
              <View style={styles.detailSubContainer}>
                <Font500 style={styles.label}>{"Sticker : "}</Font500>
                <Font700 style={styles.value}>
                  {ItemData?.packing_sticker}
                </Font700>
              </View>
              <View style={styles.detailSubContainer}>
                <Font500 style={styles.label}>{"Carton : "}</Font500>
                <Font700 style={styles.value}>
                  {ItemData?.packing_carton}
                </Font700>
              </View>
            </View>
            <View style={styles.line} />
            <View style={styles.detailContainer}>
              <View style={styles.detailSubContainer}>
                <Font500 style={styles.label}>{"Rolls : "}</Font500>
                <Font700 style={styles.value}>
                  {ItemData?.rolls_in_1_bdl}
                </Font700>
              </View>
              <View style={styles.detailSubContainer}>
                <Font500 style={styles.label}>{"Pipe : "}</Font500>
                <Font700 style={styles.value}>{ItemData?.pipe_size}</Font700>
              </View>
            </View>
            <View style={styles.line} />
            {/* <View style={styles.detailContainer}>
              <View style={styles.detailSubContainer}>
                <Font500 style={styles.label}>{"Bharati : "}</Font500>
                <Font700 style={styles.value}>
                  {ItemData?.packing_bharti}
                </Font700>
              </View>
            </View>
            <View style={styles.line} /> */}
            <View style={styles.detailContainer}>
              <View style={styles.detailSubContainer}>
                <Font500 style={styles.label}>
                  {"Packing Marital Name : "}
                </Font500>
                <Font700 style={styles.value}>
                  {ItemData?.material_name}
                </Font700>
              </View>
            </View>
            <View style={styles.line} />
            <Button
              icon={images.print}
              iconStyle={{ height: 28, width: 28 }}
              buttonTextStyle={styles.printButtonText}
              buttonContainerStyle={styles.printButton}
              onPress={onPrintModalOPen}
            >
              {"Print"}
            </Button>
          </View>
          {ItemData?.status === "pending" && (
            <View>
              <Input
                ref={labour}
                config={{ placeholder: "Labour Name" }}
                rootStyle={styles.inputContainer}
                label="Labour Name"
              />
              <Input
                ref={date}
                default_value={moment().format("DD-MM-YYYY")}
                rootStyle={styles.inputContainer}
                label="Date (DD-MM-YYYY)"
                config={{ editable: false }}
              />
              <Input
                ref={bags}
                config={{ placeholder: "2" }}
                rootStyle={styles.inputContainer}
                label="Bags/Box Qty"
              />

              <View style={styles.stepContainer}>
                <Font500 style={styles.stepLabel}>{"STEPING REQUIRED"}</Font500>
                <View style={styles.stepSubContainer}>
                  <Pressable
                    onPress={() => setSelectedStep(Step.YES)}
                    style={[
                      selectedStep === Step.YES
                        ? styles.selectedStep
                        : styles.step
                    ]}
                  >
                    <Font500
                      style={[
                        selectedStep === Step.YES
                          ? styles?.selectedStepValue
                          : styles?.stepValue
                      ]}
                    >
                      {Step.YES}
                    </Font500>
                  </Pressable>
                  <Pressable
                    onPress={() => setSelectedStep(Step.NO)}
                    style={[
                      selectedStep === Step.NO
                        ? styles.selectedStep
                        : styles.step
                    ]}
                  >
                    <Font500
                      style={[
                        selectedStep === Step.NO
                          ? styles?.selectedStepValue
                          : styles?.stepValue
                      ]}
                    >
                      {Step.NO}
                    </Font500>
                  </Pressable>
                </View>
              </View>

              <Input
                ref={steping_required}
                config={{ placeholder: "Steping Required" }}
                rootStyle={styles.inputContainer}
                label="Remarks"
              />
            </View>
          )}
        </View>
        <View style={styles.container}>
          <Font500 style={styles.orderHistory}>{"Order History #"}</Font500>
          <FlatList
            data={list}
            renderItem={renderItemHandler}
            contentContainerStyle={styles.list}
            showsVerticalScrollIndicator={false}
            keyExtractor={(_, index: number) => index?.toString()}
            // ListHeaderComponent={
            //   <>
            //     <PackingItems
            //       onPress={onNavigatePackingAddCompletedOrder}
            //       data={ItemData}
            //     />
            //     <ItemSeparatorComponent />
            //   </>
            // }
            ItemSeparatorComponent={ItemSeparatorComponent}
            ListEmptyComponent={
              <EmptyList
                loader={loader}
                message="Not have any history of this order!"
              />
            }
            refreshControl={
              <RefreshControl
                tintColor={colors.color_22534F}
                refreshing={refresh}
                onRefresh={refreshList}
              />
            }
          />
        </View>
      </ScrollView>
      <Button
        loader={loader}
        icon={images.complete}
        iconStyle={styles.buttonIcon}
        onPress={onCompleteOrderHandler}
        buttonTextStyle={styles.buttonText}
        buttonContainerStyle={styles.button}
      >
        {"Save"}
      </Button>
      <PrintModal
        title={"Print"}
        subTitle={"Show Length?"}
        ref={printModel}
        onPress={onPrintModalOPen}
      />
    </View>
  );
};

export default memo(PackingAddCompletedOrder);

const styles = StyleSheet.create({
  root: {
    flex: 1
  },
  scrollRoot: {
    flexGrow: 1,
    paddingBottom: 100
  },
  container: {
    padding: 17,
    marginTop: 32,
    borderWidth: 1,
    borderRadius: 12,
    marginHorizontal: 24,
    borderColor: colors.color_D5E4E3,
    backgroundColor: colors.color_F4F8F7
  },
  orderId: {
    fontSize: 18
  },
  detail: {
    backgroundColor: colors.white,
    borderRadius: 12,
    paddingVertical: 3,
    marginTop: 23
  },
  detailContainer: {
    flexDirection: "row",
    paddingHorizontal: 13,
    paddingVertical: 10
  },
  detailSubContainer: {
    flex: 1,
    flexDirection: "row"
  },
  label: {
    fontSize: 14,
    color: colors.color_777777
  },
  value: { fontSize: 14, color: colors.color_0B2624 ,width:wp("25%")},
  line: {
    height: 1,
    backgroundColor: colors.color_E8DBDF,
  },
  printButton: {
    marginTop: 26,
    borderWidth: 1,
    marginBottom: 19,
    marginHorizontal: 16,
    borderColor: colors.color_22534F,
    backgroundColor: colors.color_F4F8F7
  },
  printButtonText: {
    color: colors.color_22534F,
    paddingHorizontal: 6,
    fontFamily: fontFamily.Font500
  },
  inputContainer: {
    marginTop: 16
  },
  stepContainer: {
    marginTop: 14
  },
  stepLabel: {
    fontSize: 14,
    marginBlock: 13
  },
  stepSubContainer: {
    flexDirection: "row"
  },
  selectedStep: {
    height: 37,
    width: 100,
    marginRight: 20,
    borderRadius: 6,
    borderWidth: 1,
    paddingRight: 20,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 20,
    borderColor: colors.color_22534F,
    backgroundColor: colors.color_22534F
  },
  step: {
    height: 37,
    width: 100,
    marginRight: 20,
    borderRadius: 6,
    borderWidth: 1,
    paddingRight: 20,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 20,
    borderColor: colors.color_0B2624,
    backgroundColor: colors.white
  },
  stepIcon: {
    height: 20,
    width: 20
  },
  selectedStepValue: {
    fontSize: 14,
    color: colors.white
  },
  stepValue: {
    fontSize: 14,
    color: colors.color_0B2624
  },
  button: {
    // marginVertical: 46,
    // marginHorizontal: 24
    marginHorizontal: 24,
    marginBottom: 30
  },
  buttonIcon: { height: 28, width: 28 },
  buttonText: {
    fontSize: 16,
    paddingHorizontal: 6,
    fontFamily: fontFamily.Font500
  },
  ///
  list: { flexGrow: 1 },
  orderHistory: {
    fontSize: 18,
    marginBottom: 20
  },
  itemSeparator: { height: 20 }
});
