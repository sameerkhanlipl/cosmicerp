import React, {
  forwardRef,
  memo,
  useCallback,
  useImperativeHandle,
  useState
} from "react";
import { Modal, StyleSheet, TouchableOpacity, View } from "react-native";
import { Font400, Font500, Font600, Font800 } from "../fonts/Fonts";
import Button from "../styles/Button";
import { colors } from "../../constants/colors";

export type PrintModalRef = {
  open: () => void;
  close: () => void;
};

type PrintModalProps = {
  title?: string;
  subTitle?: string;
  onPress?: () => void;
};

const PrintModal = forwardRef<PrintModalRef, PrintModalProps>(
  ({ title, subTitle, onPress }, ref) => {
    const [visible, setVisible] = useState(false);
    const [select, setSelect] = useState("");

    const close = useCallback(() => {
        setSelect("");
      setVisible(false);
    }, []);

    useImperativeHandle(
      ref,
      () => {
        return {
          open: () => setVisible(true),
          close: close
        };
      },
      [close]
    );

    return (
      <Modal
        visible={visible}
        transparent={true}
        statusBarTranslucent={true}
        animationType="fade"
      >
        <View style={styles.model}>
          <View style={styles.content}>
            <View style={styles.titleContainer}>
              <Font800 style={styles.title}>{title}</Font800>
            </View>
          <View style={styles.showContainer}>
              <Font600 style={styles.showButtonText}>
                {"Show Length : "}
              </Font600>
              <TouchableOpacity style={select==="Yes"?styles.showButtonSelect:styles.showButton} onPress={()=>setSelect("Yes")}>
                <Font400 style={select==="Yes"?styles.showButtonTextSelect:styles.showButtonText}>{"Yes"}</Font400>
              </TouchableOpacity>
              <TouchableOpacity style={select==="No"?styles.showButtonSelect:styles.showButton} onPress={()=>setSelect("No")}>
                <Font400 style={select==="No"?styles.showButtonTextSelect:styles.showButtonText}>{"No"}</Font400>
              </TouchableOpacity>
            </View>
            <View style={styles.buttonContainer}>
              <Button
                onPress={close}
                buttonContainerStyle={styles.cancelButton}
                buttonTextStyle={styles.cancelButtonText}
              >
                {"Cancel"}
              </Button>
              <Button
                onPress={onPress}
                buttonContainerStyle={styles.confirmButton}
              >
                {"Confirm"}
              </Button>
            </View>
          </View>
        </View>
      </Modal>
    );
  }
);

export default memo(PrintModal);

const styles = StyleSheet.create({
  model: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: colors.transparent_black
  },
  content: {
    backgroundColor: colors.white,
    padding: 16,
    paddingVertical: 24,
    borderRadius: 10,
    width: "89%"
  },
  titleContainer: {
    marginBottom: 10,
    borderBottomWidth: 1,
    borderBlockColor: colors.lightGray
  },
  title: {
    fontSize: 22,
    marginBottom: 5,
    color: colors.color_22534F
  },
  subTitle: {
    marginBottom: 20
  },
  buttonContainer: {
    flexDirection: "row"
  },
  showContainer: {
    alignItems: "center",
    flexDirection: "row",
    justifyContent: "space-between",
    paddingHorizontal: 10,
    marginVertical: 15,
    borderWidth: 0.5,
    padding:10,
    borderRadius:5
  },
  showButton: {
    // flex: 1,
    borderRadius: 5,
    paddingHorizontal: 20,
   
    borderWidth: 0.5,
    backgroundColor: colors.white,
  },
  showButtonSelect: {
    // flex: 1,
    borderRadius: 5,
    paddingHorizontal: 20,
 backgroundColor:colors.color_22534F,
  borderWidth: 0.5,
       },
  showButtonText: {
    color: colors.black
  },
  showButtonTextSelect: {
    color: colors.white
  },
  cancelButton: {
    flex: 1,
    height: 40,
    paddingHorizontal: 20,
    backgroundColor: colors.white,
    borderWidth: 1,
    marginRight: 10
  },
  cancelButtonText: {
    color: colors.black
  },
  confirmButton: {
    flex: 1,
    height: 40,
    paddingHorizontal: 20,
    marginLeft: 10
  }
});
