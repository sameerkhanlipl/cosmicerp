import {StyleSheet, Text, View} from 'react-native';
import React from 'react';

const PackingSearchOrders = () => {
  return (
    <View>
      <Text>PackingSearchOrders</Text>
    </View>
  );
};

export default PackingSearchOrders;

const styles = StyleSheet.create({});
