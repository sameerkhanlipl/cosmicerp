import { useIsFocused, useNavigation } from "@react-navigation/native";
import React, { useCallback, useEffect, useState } from "react";
import { FlatList, StyleSheet, View } from "react-native";
import { lamination_search_orders } from "../../api/apis";
import { lamination_search_order_body } from "../../api/BodyTypes";
import { lamination_search_order_listing_response } from "../../api/ResponseTypes";
import { images } from "../../assets/images";
import CommonHeader from "../../components/styles/CommonHeader";
import EmptyList from "../../components/styles/EmptyList";
import { AppNavigationProp } from "../../stacks/StackTypes";
import { error } from "../../utils/ErrorHandler";
import LaminationSearchOrderItem, {
  LaminationSearchOrderItemType
} from "./LaminationSearchOrderItem";

const ItemSeparatorComponent = () => <View style={styles.itemSeparator} />;

const LaminationSearchOrders = () => {
  const [list, setList] = useState<LaminationSearchOrderItemType[]>([]);
  const [loader, setLoader] = useState<boolean>(false);
  const [search, setSearch] = useState<string>("18Dec24-01");
  const navigate = useNavigation<AppNavigationProp>();
  const focus = useIsFocused();
  const getList = useCallback(async () => {
    try {
      setLoader(true);
      const body: lamination_search_order_body = {
        order_id: search
      };
      const response: { data: lamination_search_order_listing_response } =
        await lamination_search_orders(body);
      setList(response?.data?.orders);
      console.log("response?.data?.orders", response?.data?.orders);
      setLoader(false);
    } catch (err: any) {
      console.log("ele?.data", err?.data);
      error(err);
      setLoader(false);
    } finally {
      setLoader(false);
    }
  }, [search]);

  useEffect(() => {
    if (focus) {
      getList();
    }
  }, [getList, focus]);

  const onNavigateLaminationOrderHistory = useCallback(
    (data: LaminationSearchOrderItemType) => {
      navigate("LaminationOrderHistory", { data: data });
    },
    [navigate]
  );

  const renderItemHandler = useCallback(
    ({ item }: { item: LaminationSearchOrderItemType }) => {
      return (
        <LaminationSearchOrderItem
          onPress={onNavigateLaminationOrderHistory}
          data={item}
        />
      );
    },
    [onNavigateLaminationOrderHistory]
  );

  return (
    <View style={styles.root}>
      <CommonHeader title={"Search Order Of Lamination"} icon={images.close} />
      <FlatList
        data={list}
        renderItem={renderItemHandler}
        contentContainerStyle={styles.list}
        showsVerticalScrollIndicator={false}
        ItemSeparatorComponent={ItemSeparatorComponent}
        keyExtractor={(_, index: number): string => index?.toString()}
        ListEmptyComponent={
          <EmptyList loader={loader} message="Not have any pending Orders!" />
        }
      />
    </View>
  );
};

export default LaminationSearchOrders;

const styles = StyleSheet.create({
  root: {
    flex: 1
  }
});
