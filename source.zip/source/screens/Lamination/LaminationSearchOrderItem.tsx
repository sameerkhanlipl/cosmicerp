import React, {FC} from 'react';
import {Text, View} from 'react-native';

export type LaminationProductionOrderType = {
  id: number;
  production_order_id: string;
  customer_order_id: string;
  customer_id: string;
  product_id: string;
  machine: string | null;
  date: string | null;
  meter: string | null;
  status: string;
  created_at: string;
  updated_at: string;
};

export type LaminationSearchOrderItemType = {
  id: number;
  customer_id: string;
  dispatched: string | null;
  order_type: string;
  contact: string;
  price_list: string | null;
  delivery_date: string;
  shipping_address: string;
  packing_name: string;
  order_id: string;
  city_id: string;
  state_id: string;
  country_id: string;
  customer_notes: string | null;
  amount: string;
  total_bundle: string;
  order_date: string;
  status: string;
  deleted_at: string | null;
  created_at: string;
  updated_at: string;
  lamination_production_orders: LaminationProductionOrderType[];
};

type LaminationSearchOrderItemProps = {
  data: LaminationSearchOrderItemType;
  onPress: (value: LaminationSearchOrderItemType) => void;
};

const LaminationSearchOrderItem: FC<LaminationSearchOrderItemProps> = () => {
  return (
    <View>
      <Text>LaminationSearchOrderItem</Text>
    </View>
  );
};

export default LaminationSearchOrderItem;
