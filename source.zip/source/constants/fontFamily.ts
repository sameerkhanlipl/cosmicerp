export enum fontFamily {
  Font400 = 'Poppins-Regular',
  Font500 = 'Poppins-Medium',
  Font600 = 'Poppins-SemiBold',
  Font700 = 'Poppins-Bold',
  Font800 = 'Poppins-ExtraBold',
}
